</div>
</div>
<script src="../resource/js/jquery.js"></script>
<script src="../resource/js/bootstrap.min.js"></script>
</body>
</html>