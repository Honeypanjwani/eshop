
<?php 
include("../autoload.php");
$db=new Db;
$obj_m=new Model($db);
$obj_c=new Controller($obj_m);
  ?>
 <?php  include("header.php");   ?>
<?php include("sidebar.php");  ?>
<div class="col-md-9">




