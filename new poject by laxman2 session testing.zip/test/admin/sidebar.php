<div class="col-md-3" >
	<ul class="list-group" style="overflow: auto !important; width: 100%;;height: 70%;overflow: auto;">
	    <li class="list-group-item"><a href="index.php">Dashboard</a></li>
	    <li class="list-group-item"><a href="insert_slider.php">Banner</a></li>
		<li class="list-group-item"><a href="banner.php">View banner</a></li>
		<li class="list-group-item"><a href="add_category.php">Add Category</a></li>
		<li class="list-group-item"><a href="view_category.php">View Category</a></li>
		<li class="list-group-item"><a href="add_sub_category.php">Add Sub Category</a></li>
		<li class="list-group-item"><a href="view_sub_category.php">View Sub Category</a></li>
		<li class="list-group-item"><a href="add_brand.php">Add Brand</a></li>
		<li class="list-group-item"><a href="view_brand.php">View Brand</a></li>
		<li class="list-group-item"><a href="add_product.php">Add Product</a></li>
		<li class="list-group-item"><a href="view_product.php">View Product</a></li>
		<li class="list-group-item"><a href="addcmt.php">Add Comment</a></li>
		<li class="list-group-item"><a href="viewcmt.php">View Comment</a></li>
		<li class="list-group-item"><a href="contact_us.php">Contact Us</a></li>
		<li class="list-group-item"><a href="view_contact_us.php">View Contact Us</a></li>
		
		
		
	</ul>
</div>